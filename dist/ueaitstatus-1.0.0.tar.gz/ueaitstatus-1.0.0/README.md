dailytao
====

A python command-line utility to display a daily chapter of the Tao Te Ching.
Content courtesy of a web scrape of [DailyTao.org](http://dailytao.org/), which is run by [Glen D Sanford](https://github.com/9len).

Setup:

```console
$ git clone https://github.com/m1keadams/dailytao.git
$ cd dailytao
$ pip install -r requirements.txt
$ pip install .
